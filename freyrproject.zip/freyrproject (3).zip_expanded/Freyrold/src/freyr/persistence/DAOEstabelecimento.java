package freyr.persistence;

import java.util.List;

import freyr.model.Estabelecimento;

public class DAOEstabelecimento extends DAO {

	public DAOEstabelecimento(){
		super();
	}
	
	public void cadastrar(Estabelecimento e) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(e); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	@SuppressWarnings("unchecked")
	public List<Estabelecimento> getLista(){
		return entityManager.createQuery("FROM Estabelecimento e").getResultList();
	}
	
public Estabelecimento visualiza(Integer id) {
		
		return entityManager.find(Estabelecimento.class, id);
	}

	public void atualizar(Estabelecimento estabelecimento) { 
		entityManager.getTransaction().begin();
		entityManager.merge(estabelecimento);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
	
	
	
	
	
	
	
}
