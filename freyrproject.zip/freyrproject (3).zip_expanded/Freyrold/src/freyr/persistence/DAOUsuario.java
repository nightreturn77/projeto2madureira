package freyr.persistence;

import javax.persistence.Query;

import freyr.model.Usuario;

public class DAOUsuario extends DAO {

	public Usuario login(String login, String senha) {
		System.out.println("Passou aqui");
		String sql = "from Usuario as u where u.login=:vLogin AND u.senha=:vSenha";

		Query query = entityManager.createQuery(sql);

		query.setParameter("vLogin", login);
		query.setParameter("vSenha", senha);

		Usuario result = (Usuario) query.getSingleResult();

		if (result != null)
			return result;
		else
			return null;

	}

	public void cadastrar(Usuario u) {
		entityManager.getTransaction().begin();
		entityManager.persist(u);
		entityManager.getTransaction().commit();
		entityManager.close();
	}
}
