package freyr.exe;

import freyr.model.Administrador;
import freyr.persistence.DAOAdministrador;

public class TestaAdm {

	public static void main(String[] args) {
		
		Administrador adm = new Administrador();
		adm.setLogin("admin");
		adm.setSenha("password");
		
		
		try {
		DAOAdministrador dao = new DAOAdministrador();
		dao.cadastrar(adm);
		System.out.println("Cadastrado com sucesso");
		}catch(Exception e) {
			System.out.println("Erro");
			e.printStackTrace();
		}
	}

	}

