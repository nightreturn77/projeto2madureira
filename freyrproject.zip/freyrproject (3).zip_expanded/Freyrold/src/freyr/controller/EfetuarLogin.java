package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import freyr.model.Usuario;
import freyr.persistence.DAOUsuario;

@WebServlet("/EfetuarLogin")
public class EfetuarLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("login.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DAOUsuario dao = new DAOUsuario();
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		
		Usuario usuario = dao.login(login,senha);
		
		if(usuario != null) {
			HttpSession session=request.getSession();  
	        session.setAttribute("login",login);
	        request.getRequestDispatcher("clienteacesso.jsp")
	        	.forward(request, response);
	        
	        session.setAttribute("usuario", usuario);
		}else {
			request.setAttribute("servMensagem", "Usu�rio Inv�lido");
			doGet(request, response);
		}
	}

}
